package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ManhwaEditItem
import com.example.ui.theme.HubAccentRose
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTertiaryAmber
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@Composable
fun ManhwaEditsSection(
  edits: List<ManhwaEditItem>,
  onEditClick: (ManhwaEditItem) -> Unit,
  onExploreEditsClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp)
  ) {
    // Section Header with "Explore Edits" button
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(HubAccentRose)
        )
        Text(
          text = "Manhwa Edits",
          color = HubTextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp,
          modifier = Modifier.testTag("manhwa_edits_title")
        )
        Text(
          text = "WEBTOON FX",
          color = HubAccentRose,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(HubAccentRose.copy(alpha = 0.15f))
            .padding(horizontal = 5.dp, vertical = 2.dp)
        )
      }

      // "Explore Edits" Button in Section Header
      Button(
        onClick = onExploreEditsClick,
        modifier = Modifier
          .height(34.dp)
          .testTag("explore_edits_button"),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = HubDarkSurfaceVariant,
          contentColor = HubAccentRose
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
          brush = Brush.horizontalGradient(listOf(HubAccentRose, HubPrimaryPurple))
        ),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Explore,
          contentDescription = null,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Explore Edits",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Four portrait previews:
    // 1. "UI Daniel"
    // 2. "Choi Hyun"
    // 3. "Gitae Kim"
    // 4. "Player Lee"
    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(edits) { editItem ->
        ManhwaPortraitCard(
          editItem = editItem,
          onClick = { onEditClick(editItem) }
        )
      }
    }
  }
}

@Composable
fun ManhwaPortraitCard(
  editItem: ManhwaEditItem,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val primaryColor = Color(editItem.primaryAuraColor)
  val secondaryColor = Color(editItem.secondaryColor)

  Card(
    modifier = modifier
      .width(132.dp)
      .aspectRatio(3f / 4f)
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, primaryColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("manhwa_card_${editItem.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = HubDarkSurface)
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Dynamic Canvas Portrait with character aura
      ManhwaPortraitCanvas(
        characterName = editItem.characterName,
        primaryColor = primaryColor,
        secondaryColor = secondaryColor,
        modifier = Modifier.fillMaxSize()
      )

      // Vignette bottom gradient
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Transparent,
                Color.Black.copy(alpha = 0.85f)
              ),
              startY = 100f
            )
          )
      )

      // Top Aura Badge
      Box(
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(8.dp)
          .clip(RoundedCornerShape(4.dp))
          .background(primaryColor.copy(alpha = 0.25f))
          .border(0.5.dp, primaryColor, RoundedCornerShape(4.dp))
          .padding(horizontal = 6.dp, vertical = 2.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
          Icon(
            imageVector = Icons.Default.FlashOn,
            contentDescription = null,
            tint = primaryColor,
            modifier = Modifier.size(10.dp)
          )
          Text(
            text = editItem.auraType,
            color = Color.White,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // Bottom Character Label
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(10.dp)
      ) {
        Text(
          text = editItem.characterName,
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 0.4.sp
        )
        Text(
          text = editItem.series,
          color = primaryColor,
          fontSize = 10.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}

/**
 * Manhwa Edit Workshop Sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManhwaEditDetailSheet(
  editItem: ManhwaEditItem,
  onDismiss: () -> Unit,
  onCopyNotification: (String) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val primaryColor = Color(editItem.primaryAuraColor)
  val secondaryColor = Color(editItem.secondaryColor)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HubDarkSurface,
    tonalElevation = 8.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = editItem.characterName,
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
          )
          Text(
            text = "${editItem.series} • ${editItem.chapterRef}",
            color = primaryColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = HubTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Visual Canvas Hero
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(200.dp)
          .clip(RoundedCornerShape(16.dp))
          .border(1.dp, primaryColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
      ) {
        ManhwaPortraitCanvas(
          characterName = editItem.characterName,
          primaryColor = primaryColor,
          secondaryColor = secondaryColor,
          modifier = Modifier.fillMaxSize()
        )

        // Manga Sound Effect Badge
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.75f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = editItem.soundEffect,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
          )
        }

        // Quote Box at bottom
        Box(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.7f))
            .padding(10.dp)
        ) {
          Text(
            text = "\"${editItem.quote}\"",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Edit Formula & Tags",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        editItem.editTags.forEach { tag ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(HubDarkSurfaceVariant)
              .border(0.5.dp, HubDarkBorder, RoundedCornerShape(20.dp))
              .padding(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text(text = tag, color = HubTextSecondary, fontSize = 10.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Action buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = {
            onCopyNotification("Copied ${editItem.characterName} Lookism Grading Recipe to clipboard!")
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = primaryColor)
        ) {
          Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Copy Formula", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = {
            onCopyNotification("Saved ${editItem.characterName} 4K Crop to Gallery")
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = HubDarkSurfaceVariant)
        ) {
          Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Download 4K", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
