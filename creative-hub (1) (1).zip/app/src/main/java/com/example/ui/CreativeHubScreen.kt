package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AIPromptItem
import com.example.model.ManhwaEditItem
import com.example.model.PresetItem
import com.example.model.WallpaperItem
import com.example.ui.components.AIPromptDetailSheet
import com.example.ui.components.AIPromptsSection
import com.example.ui.components.EditingPresetsSection
import com.example.ui.components.ManhwaEditDetailSheet
import com.example.ui.components.ManhwaEditsSection
import com.example.ui.components.PresetDetailSheet
import com.example.ui.components.SavedBookmarksSheet
import com.example.ui.components.StudioHeader
import com.example.ui.components.WallpaperDetailDialog
import com.example.ui.components.WallpaperGallerySheet
import com.example.ui.components.WallpaperHavenSection
import com.example.ui.theme.HubDarkBackground
import kotlinx.coroutines.launch

@Composable
fun CreativeHubScreen(modifier: Modifier = Modifier) {
  val clipboardManager = LocalClipboardManager.current
  val snackbarHostState = remember { SnackbarHostState() }
  val coroutineScope = rememberCoroutineScope()

  // State management
  var searchQuery by remember { mutableStateOf("") }
  var isSearchActive by remember { mutableStateOf(false) }
  var selectedCategoryTab by remember { mutableStateOf("All Vault") }

  // Modals & Sheets state
  var selectedWallpaper by remember { mutableStateOf<WallpaperItem?>(null) }
  var isViewAllWallpapersOpen by remember { mutableStateOf(false) }
  var selectedPreset by remember { mutableStateOf<PresetItem?>(null) }
  var selectedManhwaEdit by remember { mutableStateOf<ManhwaEditItem?>(null) }
  var selectedAIPrompt by remember { mutableStateOf<AIPromptItem?>(null) }
  var isBookmarksSheetOpen by remember { mutableStateOf(false) }

  // Bookmarks
  val bookmarkedTitles = remember {
    mutableStateListOf("Dark Aesthetics", "Vintage Vibe", "UI Daniel")
  }

  // 1. Wallpaper Haven Data
  // "Dark Aesthetics" (an astronaut), "Cyberpunk" (neon city), "Nature High-Res" (mountain), and a "VIEW ALL" button
  val wallpapers = remember {
    listOf(
      WallpaperItem(
        id = "dark_aesthetics",
        title = "Dark Aesthetics",
        category = "Dark Aesthetics",
        tag = "ASTRONAUT 4K",
        imageRes = R.drawable.img_dark_astronaut,
        downloads = "48.2k",
        resolution = "3840 × 2160 UHD",
        fileSize = "14.2 MB",
        paletteColors = listOf(0xFF1E1B4B, 0xFF7C3AED, 0xFF090A0F)
      ),
      WallpaperItem(
        id = "cyberpunk",
        title = "Cyberpunk",
        category = "Cyberpunk",
        tag = "NEON CITY",
        imageRes = R.drawable.img_cyberpunk_city,
        downloads = "64.9k",
        resolution = "3840 × 2160 UHD",
        fileSize = "16.8 MB",
        paletteColors = listOf(0xFF06B6D4, 0xFFEC4899, 0xFF0B0F19)
      ),
      WallpaperItem(
        id = "nature_high_res",
        title = "Nature High-Res",
        category = "Nature High-Res",
        tag = "ALPINE 8K",
        imageRes = R.drawable.img_nature_mountain,
        downloads = "39.1k",
        resolution = "7680 × 4320 8K",
        fileSize = "22.5 MB",
        paletteColors = listOf(0xFF0284C7, 0xFF0D9488, 0xFF021B1A)
      )
    )
  }

  // Additional Wallpapers for "VIEW ALL" Gallery
  val allWallpapers = remember {
    wallpapers + listOf(
      WallpaperItem(
        id = "minimal_cosmic",
        title = "Cosmic Eclipse",
        category = "Dark Aesthetics",
        tag = "DEEP VOID",
        imageRes = R.drawable.img_dark_astronaut,
        downloads = "18.5k"
      ),
      WallpaperItem(
        id = "cyber_rain",
        title = "Rainy Shibuya",
        category = "Cyberpunk",
        tag = "CYAN SHADOW",
        imageRes = R.drawable.img_cyberpunk_city,
        downloads = "29.4k"
      ),
      WallpaperItem(
        id = "misty_peaks",
        title = "Misty Fjord",
        category = "Nature High-Res",
        tag = "NORDIC",
        imageRes = R.drawable.img_nature_mountain,
        downloads = "22.1k"
      )
    )
  }

  // 2. Editing Presets Data
  // "Vintage Vibe" (portrait), "Cinematic LUTs" (city bridge), "Slo Mo Effect" (running figure)
  val presets = remember {
    listOf(
      PresetItem(
        id = "vintage_vibe",
        title = "Vintage Vibe",
        subtitle = "Warm 35mm golden film aesthetic for portraits",
        category = "Portrait Film",
        imageRes = R.drawable.img_vintage_portrait,
        presetType = "DNG + XMP Pack",
        downloadCount = "24,800+",
        exposure = 0.20f,
        contrast = 0.45f,
        highlights = -0.25f,
        shadows = 0.35f,
        temp = 0.28f,
        grain = 0.40f,
        description = "Emulates Kodak Portra 400 warmth with lifted blacks, organic halation, and creamy skin tones."
      ),
      PresetItem(
        id = "cinematic_luts",
        title = "Cinematic LUTs",
        subtitle = "Moody teal & orange bridge grading with dusk glow",
        category = "Cityscape & Travel",
        imageRes = null, // uses procedural CinematicBridgeArtwork
        presetType = ".CUBE (DaVinci / Premiere)",
        downloadCount = "31,400+",
        exposure = 0.10f,
        contrast = 0.55f,
        highlights = -0.40f,
        shadows = 0.15f,
        temp = -0.10f,
        grain = 0.20f,
        description = "Hollywood blockbuster color profile separating cyan skylines with rich tungsten bridge lighting."
      ),
      PresetItem(
        id = "slo_mo_effect",
        title = "Slo Mo Effect",
        subtitle = "Kinetic shutter curve & motion blur for action",
        category = "Action & Sports",
        imageRes = null, // uses procedural SloMoRunnerArtwork
        presetType = "CapCut / Premiere Curve",
        downloadCount = "42,100+",
        exposure = 0.15f,
        contrast = 0.60f,
        highlights = -0.15f,
        shadows = 0.25f,
        temp = 0.05f,
        grain = 0.15f,
        description = "Ultra smooth optical flow timing curves tuned for 120fps/240fps sports footage."
      )
    )
  }

  // 3. Manhwa Edits Data
  // Four portrait previews: "UI Daniel," "Choi Hyun," "Gitae Kim," "Player Lee," with an "Explore Edits" button
  val manhwaEdits = remember {
    listOf(
      ManhwaEditItem(
        id = "ui_daniel",
        characterName = "UI Daniel",
        series = "Lookism",
        auraType = "Ultra Instinct",
        primaryAuraColor = 0xFF8B5CF6,
        secondaryColor = 0xFF000000,
        chapterRef = "Ep. 467 - Peak Battle",
        soundEffect = "CRACKLE!",
        quote = "The body moves purely on combat perfection.",
        editTags = listOf("Lookism", "UI State", "Martial Arts", "Heavy Grain")
      ),
      ManhwaEditItem(
        id = "choi_hyun",
        characterName = "Choi Hyun",
        series = "Questism",
        auraType = "Quest System Aura",
        primaryAuraColor = 0xFF06B6D4,
        secondaryColor = 0xFF0284C7,
        chapterRef = "Ep. 112 - Awakened Card",
        soundEffect = "SYSTEM BEEP",
        quote = "Stat window detected: Challenger surpassed limit.",
        editTags = listOf("Questism", "Hologram Blue", "Glitch FX", "Vivid HDR")
      ),
      ManhwaEditItem(
        id = "gitae_kim",
        characterName = "Gitae Kim",
        series = "Lookism",
        auraType = "Crimson Monarch",
        primaryAuraColor = 0xFFF43F5E,
        secondaryColor = 0xFF7F1D1D,
        chapterRef = "Ep. 504 - Mexico King",
        soundEffect = "THUMP...",
        quote = "The ruthless king who inherited brute power.",
        editTags = listOf("King of Seoul", "Blood Aura", "Dark Shading", "High Contrast")
      ),
      ManhwaEditItem(
        id = "player_lee",
        characterName = "Player Lee",
        series = "Solo Player",
        auraType = "Shadow Hunter",
        primaryAuraColor = 0xFFA855F7,
        secondaryColor = 0xFF3B82F6,
        chapterRef = "Ep. 178 - Arise",
        soundEffect = "WHOOSH!",
        quote = "From E-rank struggle to ruler of the dark domain.",
        editTags = listOf("Hunter Solo", "Purple Extraction", "Dagger Trail", "Webtoon CC")
      )
    )
  }

  // 4. AI Prompts Data
  // "Fantasy Landscape," "Sci-Fi Cityscape," "Cyberpunk Portrait," and "Detailed character portrait"
  val aiPrompts = remember {
    listOf(
      AIPromptItem(
        id = "fantasy_landscape",
        title = "Fantasy Landscape",
        promptText = "An ancient ethereal floating sanctuary bathed in twilight violet light, colossal waterfalls cascading into clouds, bioluminescent flora, hyper-detailed digital matte painting, 8k render, Unreal Engine 5 aesthetic --ar 16:9 --stylize 750",
        negativePrompt = "blurry, low resolution, washed out, modern buildings, cartoonish, watermark, oversaturated colors",
        aspectRatio = "16:9",
        recommendedModel = "Midjourney v6.1",
        tags = listOf("Environment", "Ethereal", "Unreal Engine 5"),
        seed = 9812401L
      ),
      AIPromptItem(
        id = "scifi_cityscape",
        title = "Sci-Fi Cityscape",
        promptText = "Megastructure vertical metropolis piercing dense stratus clouds, neon sky-train transit loops, holographic advertisements refracting in rain, volumetric fog, Octane render, cinematic lighting --ar 16:9 --v 6.1",
        negativePrompt = "low poly, plastic look, blurry details, daytime sunshine, rural, distorted lines",
        aspectRatio = "16:9",
        recommendedModel = "Flux.1 Schnell",
        tags = listOf("Futuristic", "Cyber-Metropolis", "Octane"),
        seed = 4429810L
      ),
      AIPromptItem(
        id = "cyberpunk_portrait",
        title = "Cyberpunk Portrait",
        promptText = "Close-up portrait of a cybernetic warrior with subtle chrome facial implants, illuminated by cyan and hot magenta neon reflections, rain droplets on visor, shot on 85mm f/1.4, cinematic color grading --ar 9:16",
        negativePrompt = "deformed anatomy, asymmetrical eyes, bad hands, plastic skin, cartoon, watermark",
        aspectRatio = "9:16",
        recommendedModel = "Midjourney v6.1",
        tags = listOf("Cyberware", "Neon Lighting", "85mm Lens"),
        seed = 6210344L
      ),
      AIPromptItem(
        id = "detailed_character_portrait",
        title = "Detailed character portrait",
        promptText = "Studio portrait of a mysterious cloaked wanderer, weathered leather textures, intense piercing hazel eyes, rim lighting, atmospheric dust particles, 8k, photorealistic character study --ar 4:5 --q 2",
        negativePrompt = "3d render look, artificial smooth skin, oversaturated, deformed pupils, blurry background noise",
        aspectRatio = "4:5",
        recommendedModel = "DALL-E 3 / SDXL",
        tags = listOf("Photorealism", "Moody Lighting", "Studio Master"),
        seed = 3105782L
      )
    )
  }

  // Filtering based on Search Query & Tab
  val filteredWallpapers = wallpapers.filter {
    searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true) || it.tag.contains(searchQuery, ignoreCase = true)
  }
  val filteredPresets = presets.filter {
    searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true) || it.category.contains(searchQuery, ignoreCase = true)
  }
  val filteredManhwa = manhwaEdits.filter {
    searchQuery.isEmpty() || it.characterName.contains(searchQuery, ignoreCase = true) || it.series.contains(searchQuery, ignoreCase = true)
  }
  val filteredPrompts = aiPrompts.filter {
    searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true) || it.promptText.contains(searchQuery, ignoreCase = true)
  }

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .background(HubDarkBackground)
      .statusBarsPadding()
      .navigationBarsPadding(),
    containerColor = HubDarkBackground,
    snackbarHost = {
      SnackbarHost(hostState = snackbarHostState)
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
    ) {
      // 1. Studio Header & Title Banner
      // "CREATIVE HUB" | "11:33"
      // Bold White Text "CREATIVE HUB" with subtitle "Presets, Wallpapers, Prompts & More"
      StudioHeader(
        currentTime = "11:33",
        searchQuery = searchQuery,
        onSearchQueryChange = { searchQuery = it },
        isSearchActive = isSearchActive,
        onToggleSearch = {
          isSearchActive = !isSearchActive
          if (!isSearchActive) searchQuery = ""
        },
        savedBookmarksCount = bookmarkedTitles.size,
        onOpenBookmarks = { isBookmarksSheetOpen = true },
        selectedCategoryTab = selectedCategoryTab,
        onSelectCategoryTab = { selectedCategoryTab = it }
      )

      // 2. Section: Wallpaper Haven
      // Shows four preview thumbnails: "Dark Aesthetics" (an astronaut), "Cyberpunk" (neon city), "Nature High-Res" (mountain), and a "VIEW ALL" button.
      if (selectedCategoryTab == "All Vault" || selectedCategoryTab == "Wallpapers") {
        WallpaperHavenSection(
          wallpapers = filteredWallpapers,
          onWallpaperClick = { wallpaper ->
            selectedWallpaper = wallpaper
          },
          onViewAllClick = {
            isViewAllWallpapersOpen = true
          }
        )
      }

      // 3. Section: Editing Presets
      // Shows three previews with "Get Presets" buttons: "Vintage Vibe" (portrait), "Cinematic LUTs" (city bridge), "Slo Mo Effect" (running figure).
      if (selectedCategoryTab == "All Vault" || selectedCategoryTab == "Editing Presets") {
        EditingPresetsSection(
          presets = filteredPresets,
          onGetPresetClick = { preset ->
            selectedPreset = preset
          }
        )
      }

      // 4. Section: Manhwa Edits
      // Shows four portrait previews: "UI Daniel," "Choi Hyun," "Gitae Kim," "Player Lee," with an "Explore Edits" button.
      if (selectedCategoryTab == "All Vault" || selectedCategoryTab == "Manhwa Edits") {
        ManhwaEditsSection(
          edits = filteredManhwa,
          onEditClick = { editItem ->
            selectedManhwaEdit = editItem
          },
          onExploreEditsClick = {
            selectedManhwaEdit = manhwaEdits.first()
          }
        )
      }

      // 5. Section: AI Prompts
      // Text boxes with buttons for "Fantasy Landscape," "Sci-Fi Cityscape," "Cyberpunk Portrait," and "Detailed character portrait."
      if (selectedCategoryTab == "All Vault" || selectedCategoryTab == "AI Prompts") {
        AIPromptsSection(
          prompts = filteredPrompts,
          onCopyPrompt = { promptItem ->
            clipboardManager.setText(AnnotatedString(promptItem.promptText))
            coroutineScope.launch {
              snackbarHostState.showSnackbar(
                message = "Copied '${promptItem.title}' prompt to clipboard!",
                duration = SnackbarDuration.Short
              )
            }
          },
          onInspectPrompt = { promptItem ->
            selectedAIPrompt = promptItem
          }
        )
      }

      Spacer(modifier = Modifier.height(40.dp))
    }
  }

  // MODALS & BOTTOM SHEETS

  // Fullscreen Wallpaper Detail Dialog
  selectedWallpaper?.let { wallpaper ->
    WallpaperDetailDialog(
      wallpaper = wallpaper,
      isBookmarked = bookmarkedTitles.contains(wallpaper.title),
      onToggleBookmark = {
        if (bookmarkedTitles.contains(wallpaper.title)) {
          bookmarkedTitles.remove(wallpaper.title)
        } else {
          bookmarkedTitles.add(wallpaper.title)
        }
      },
      onDismiss = { selectedWallpaper = null },
      onApplyToast = { msg ->
        coroutineScope.launch {
          snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
      }
    )
  }

  // Wallpaper Haven "VIEW ALL" Gallery Sheet
  if (isViewAllWallpapersOpen) {
    WallpaperGallerySheet(
      wallpapers = allWallpapers,
      onSelectWallpaper = { wallpaper ->
        isViewAllWallpapersOpen = false
        selectedWallpaper = wallpaper
      },
      onDismiss = { isViewAllWallpapersOpen = false }
    )
  }

  // Editing Preset Studio Detail Sheet
  selectedPreset?.let { preset ->
    PresetDetailSheet(
      preset = preset,
      onDismiss = { selectedPreset = null },
      onDownloadNotification = { msg ->
        coroutineScope.launch {
          snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
      }
    )
  }

  // Manhwa Edit Detail Sheet
  selectedManhwaEdit?.let { editItem ->
    ManhwaEditDetailSheet(
      editItem = editItem,
      onDismiss = { selectedManhwaEdit = null },
      onCopyNotification = { msg ->
        coroutineScope.launch {
          snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
      }
    )
  }

  // AI Prompt Inspector & Refiner Sheet
  selectedAIPrompt?.let { promptItem ->
    AIPromptDetailSheet(
      item = promptItem,
      onDismiss = { selectedAIPrompt = null },
      onCopyNotification = { msg ->
        clipboardManager.setText(AnnotatedString(msg))
        coroutineScope.launch {
          snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
      }
    )
  }

  // Saved Bookmarks / Favorites Sheet
  if (isBookmarksSheetOpen) {
    SavedBookmarksSheet(
      bookmarkedItems = bookmarkedTitles,
      onRemoveBookmark = { title ->
        bookmarkedTitles.remove(title)
      },
      onDismiss = { isBookmarksSheetOpen = false }
    )
  }
}
