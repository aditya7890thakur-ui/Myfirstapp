package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PresetItem
import com.example.ui.theme.HubAccentRose
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTertiaryAmber
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@Composable
fun EditingPresetsSection(
  presets: List<PresetItem>,
  onGetPresetClick: (PresetItem) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp)
  ) {
    // Section Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(HubSecondaryCyan)
        )
        Text(
          text = "Editing Presets",
          color = HubTextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp,
          modifier = Modifier.testTag("editing_presets_title")
        )
        Text(
          text = "LUTs & DNG",
          color = HubTertiaryAmber,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(HubTertiaryAmber.copy(alpha = 0.15f))
            .padding(horizontal = 5.dp, vertical = 2.dp)
        )
      }

      Text(
        text = "3 PACKS",
        color = HubTextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Shows three previews with "Get Presets" buttons:
    // 1. "Vintage Vibe" (portrait)
    // 2. "Cinematic LUTs" (city bridge)
    // 3. "Slo Mo Effect" (running figure)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      presets.forEach { preset ->
        PresetCard(
          preset = preset,
          onGetPreset = { onGetPresetClick(preset) }
        )
      }
    }
  }
}

@Composable
fun PresetCard(
  preset: PresetItem,
  onGetPreset: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, HubDarkBorder, RoundedCornerShape(16.dp))
      .testTag("preset_card_${preset.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = HubDarkSurface)
  ) {
    Column {
      // Visual Preview Container (3:2 aspect ratio)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(180.dp)
      ) {
        when (preset.id) {
          "vintage_vibe" -> {
            if (preset.imageRes != null) {
              Image(
                painter = painterResource(id = preset.imageRes),
                contentDescription = preset.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
            }
          }
          "cinematic_luts" -> {
            CinematicBridgeArtwork(modifier = Modifier.fillMaxSize())
          }
          "slo_mo_effect" -> {
            SloMoRunnerArtwork(modifier = Modifier.fillMaxSize())
          }
          else -> {
            if (preset.imageRes != null) {
              Image(
                painter = painterResource(id = preset.imageRes),
                contentDescription = preset.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
            } else {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(HubDarkSurfaceVariant)
              )
            }
          }
        }

        // Gradient overlay for contrast
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Black.copy(alpha = 0.35f),
                  Color.Transparent,
                  Color.Black.copy(alpha = 0.75f)
                )
              )
            )
        )

        // Top Badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color.Black.copy(alpha = 0.7f))
              .border(0.5.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = preset.category.uppercase(),
              color = Color.White,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.8.sp
            )
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(HubDarkSurfaceVariant.copy(alpha = 0.85f))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = preset.presetType,
              color = HubSecondaryCyan,
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        // Bottom Title on Image
        Column(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(12.dp)
        ) {
          Text(
            text = preset.title,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = preset.subtitle,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 12.sp
          )
        }
      }

      // Bottom Action Bar with "Get Presets" button
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(HubDarkSurfaceVariant)
          .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Download,
              contentDescription = null,
              tint = HubTextMuted,
              modifier = Modifier.size(12.dp)
            )
            Text(
              text = "${preset.downloadCount} creators",
              color = HubTextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            )
          }
          Text(
            text = "Includes Lightroom & DaVinci .CUBE",
            color = HubTextMuted,
            fontSize = 10.sp
          )
        }

        // Dedicated "Get Presets" button
        Button(
          onClick = onGetPreset,
          modifier = Modifier
            .height(38.dp)
            .testTag("get_preset_button_${preset.id}"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = HubPrimaryPurple
          )
        ) {
          Icon(
            imageVector = Icons.Default.Tune,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Get Presets",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

/**
 * Interactive Preset Inspector & Tuning Sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresetDetailSheet(
  preset: PresetItem,
  onDismiss: () -> Unit,
  onDownloadNotification: (String) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var splitSliderPos by remember { mutableFloatStateOf(0.5f) }
  var exposureVal by remember { mutableFloatStateOf(preset.exposure) }
  var contrastVal by remember { mutableFloatStateOf(preset.contrast) }
  var grainVal by remember { mutableFloatStateOf(preset.grain) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HubDarkSurface,
    tonalElevation = 8.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = preset.title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = preset.presetType,
            color = HubSecondaryCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = HubTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Before / After Preview Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(200.dp)
          .clip(RoundedCornerShape(14.dp))
          .border(1.dp, HubDarkBorder, RoundedCornerShape(14.dp))
      ) {
        when (preset.id) {
          "vintage_vibe" -> {
            if (preset.imageRes != null) {
              Image(
                painter = painterResource(id = preset.imageRes),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
            }
          }
          "cinematic_luts" -> CinematicBridgeArtwork(modifier = Modifier.fillMaxSize())
          "slo_mo_effect" -> SloMoRunnerArtwork(modifier = Modifier.fillMaxSize())
        }

        // Before / After badge
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(Color.Black.copy(alpha = 0.6f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text("BEFORE: RAW", color = HubTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(HubPrimaryPurple.copy(alpha = 0.8f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text("AFTER: GRADED", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Color Grading Profile Parameters",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Interactive Exposure adjustment
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Exposure", color = Color.White, fontSize = 12.sp)
        Text(String.format("+%.2f EV", exposureVal), color = HubSecondaryCyan, fontSize = 12.sp)
      }
      Slider(
        value = exposureVal,
        onValueChange = { exposureVal = it },
        valueRange = -1.0f..1.0f,
        colors = SliderDefaults.colors(
          thumbColor = HubSecondaryCyan,
          activeTrackColor = HubSecondaryCyan,
          inactiveTrackColor = HubDarkSurfaceVariant
        )
      )

      // Contrast adjustment
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Contrast Curve", color = Color.White, fontSize = 12.sp)
        Text(String.format("%.0f%%", contrastVal * 100), color = HubPrimaryPurple, fontSize = 12.sp)
      }
      Slider(
        value = contrastVal,
        onValueChange = { contrastVal = it },
        valueRange = 0f..1.0f,
        colors = SliderDefaults.colors(
          thumbColor = HubPrimaryPurple,
          activeTrackColor = HubPrimaryPurple,
          inactiveTrackColor = HubDarkSurfaceVariant
        )
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Download Formats Action Row
      Text(
        text = "Download Preset Package",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = {
            onDownloadNotification("Downloaded '${preset.title}.dng' (Lightroom Mobile)")
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = HubPrimaryPurple)
        ) {
          Text(".DNG", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        Button(
          onClick = {
            onDownloadNotification("Downloaded '${preset.title}.cube' (3D LUT Profile)")
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = HubSecondaryCyan)
        ) {
          Text(".CUBE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        Button(
          onClick = {
            onDownloadNotification("Downloaded '${preset.title}.xmp' (Camera Raw / Desktop)")
          },
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = HubDarkSurfaceVariant)
        ) {
          Text(".XMP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
