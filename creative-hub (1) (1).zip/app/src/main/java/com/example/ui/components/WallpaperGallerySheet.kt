package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.WallpaperItem
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperGallerySheet(
  wallpapers: List<WallpaperItem>,
  onSelectWallpaper: (WallpaperItem) -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedCategory by remember { mutableStateOf("All") }
  var filterQuery by remember { mutableStateOf("") }

  val categories = listOf("All", "Dark Aesthetics", "Cyberpunk", "Nature High-Res", "Minimalist")

  val filteredWallpapers = wallpapers.filter { item ->
    val matchCategory = selectedCategory == "All" || item.category.equals(selectedCategory, ignoreCase = true)
    val matchQuery = filterQuery.isEmpty() || item.title.contains(filterQuery, ignoreCase = true) || item.tag.contains(filterQuery, ignoreCase = true)
    matchCategory && matchQuery
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HubDarkSurface,
    tonalElevation = 8.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Wallpaper Haven Gallery",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "4K / 8K Curated Showcase (${wallpapers.size} Assets)",
            color = HubSecondaryCyan,
            fontSize = 12.sp
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = HubTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Category chips
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        categories.forEach { cat ->
          val isSelected = selectedCategory == cat
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(if (isSelected) HubPrimaryPurple else HubDarkSurfaceVariant)
              .border(1.dp, if (isSelected) HubPrimaryPurple else HubDarkBorder, RoundedCornerShape(20.dp))
              .clickable { selectedCategory = cat }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(
              text = cat,
              color = if (isSelected) Color.White else HubTextSecondary,
              fontSize = 12.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Grid of Wallpapers
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
          .fillMaxWidth()
          .height(420.dp),
        contentPadding = PaddingValues(bottom = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredWallpapers) { wallpaper ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .aspectRatio(9f / 16f)
              .clip(RoundedCornerShape(12.dp))
              .border(1.dp, HubDarkBorder, RoundedCornerShape(12.dp))
              .clickable {
                onSelectWallpaper(wallpaper)
              }
          ) {
            if (wallpaper.imageRes != null) {
              Image(
                painter = painterResource(id = wallpaper.imageRes),
                contentDescription = wallpaper.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
            } else {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(HubDarkSurfaceVariant)
              )
            }

            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors = listOf(
                      Color.Transparent,
                      Color.Black.copy(alpha = 0.8f)
                    ),
                    startY = 80f
                  )
                )
            )

            Column(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
            ) {
              Text(
                text = wallpaper.title,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = wallpaper.tag,
                color = HubSecondaryCyan,
                fontSize = 10.sp
              )
            }
          }
        }
      }
    }
  }
}
