package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AIPromptItem
import com.example.ui.theme.HubAccentEmerald
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTertiaryAmber
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@Composable
fun AIPromptsSection(
  prompts: List<AIPromptItem>,
  onCopyPrompt: (AIPromptItem) -> Unit,
  onInspectPrompt: (AIPromptItem) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp)
  ) {
    // Section Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(HubTertiaryAmber)
        )
        Text(
          text = "AI Prompts",
          color = HubTextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp,
          modifier = Modifier.testTag("ai_prompts_title")
        )
        Text(
          text = "PROMPT GENIUS",
          color = HubTertiaryAmber,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(HubTertiaryAmber.copy(alpha = 0.15f))
            .padding(horizontal = 5.dp, vertical = 2.dp)
        )
      }

      Text(
        text = "READY TO COPY",
        color = HubTextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Text boxes with buttons for:
    // 1. "Fantasy Landscape"
    // 2. "Sci-Fi Cityscape"
    // 3. "Cyberpunk Portrait"
    // 4. "Detailed character portrait"
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      prompts.forEach { promptItem ->
        AIPromptCard(
          item = promptItem,
          onCopy = { onCopyPrompt(promptItem) },
          onInspect = { onInspectPrompt(promptItem) }
        )
      }
    }
  }
}

@Composable
fun AIPromptCard(
  item: AIPromptItem,
  onCopy: () -> Unit,
  onInspect: () -> Unit,
  modifier: Modifier = Modifier
) {
  var hasCopied by remember { mutableStateOf(false) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, HubDarkBorder, RoundedCornerShape(16.dp))
      .testTag("prompt_card_${item.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = HubDarkSurface)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Top header with Title & Model badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(
            modifier = Modifier
              .size(24.dp)
              .clip(CircleShape)
              .background(HubTertiaryAmber.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Psychology,
              contentDescription = null,
              tint = HubTertiaryAmber,
              modifier = Modifier.size(14.dp)
            )
          }

          Text(
            text = item.title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.testTag("prompt_title_${item.id}")
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(HubDarkSurfaceVariant)
            .border(0.5.dp, HubDarkBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
          Text(
            text = item.recommendedModel,
            color = HubSecondaryCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Prompt Text Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0xFF07080D))
          .border(1.dp, Color(0xFF1E2333), RoundedCornerShape(10.dp))
          .padding(12.dp)
          .testTag("prompt_box_${item.id}")
      ) {
        Text(
          text = item.promptText,
          color = Color(0xFFE2E8F0),
          fontSize = 13.sp,
          fontFamily = FontFamily.SansSerif,
          lineHeight = 18.sp
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Tag chips row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(HubDarkSurfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(text = "Aspect: ${item.aspectRatio}", color = HubTextMuted, fontSize = 10.sp)
        }

        item.tags.take(2).forEach { tag ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(HubDarkSurfaceVariant)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(text = tag, color = HubTextMuted, fontSize = 10.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action buttons row: "Copy Prompt" and "Inspect Details"
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = {
            hasCopied = true
            onCopy()
          },
          modifier = Modifier
            .weight(1.3f)
            .height(38.dp)
            .testTag("copy_prompt_button_${item.id}"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (hasCopied) HubAccentEmerald else HubPrimaryPurple
          )
        ) {
          Icon(
            imageVector = if (hasCopied) Icons.Default.Check else Icons.Default.ContentCopy,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (hasCopied) "Copied!" else "Copy Prompt",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        OutlinedButton(
          onClick = onInspect,
          modifier = Modifier
            .weight(1f)
            .height(38.dp)
            .testTag("inspect_prompt_button_${item.id}"),
          shape = RoundedCornerShape(10.dp),
          border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(listOf(HubDarkBorder, HubSecondaryCyan))
          ),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = HubSecondaryCyan)
        ) {
          Icon(
            imageVector = Icons.Default.Tune,
            contentDescription = null,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Inspect", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

/**
 * AI Prompt Inspector & Refiner Sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIPromptDetailSheet(
  item: AIPromptItem,
  onDismiss: () -> Unit,
  onCopyNotification: (String) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedAR by remember { mutableStateOf(item.aspectRatio) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = HubDarkSurface,
    tonalElevation = 8.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = item.title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Engine: ${item.recommendedModel}",
            color = HubSecondaryCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = HubTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Full Generation Prompt",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(6.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF07080D))
          .border(1.dp, HubDarkBorder, RoundedCornerShape(12.dp))
          .padding(14.dp)
      ) {
        Text(
          text = item.promptText,
          color = Color(0xFFF1F5F9),
          fontSize = 13.sp,
          lineHeight = 19.sp
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "Negative Prompt (Filters & Exclusions)",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(6.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(HubDarkSurfaceVariant)
          .padding(12.dp)
      ) {
        Text(
          text = item.negativePrompt,
          color = HubTextMuted,
          fontSize = 12.sp,
          lineHeight = 16.sp
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Aspect Ratio Selector Chips
      Text(
        text = "Select Aspect Ratio",
        color = HubTextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("16:9", "9:16", "1:1", "4:5").forEach { ar ->
          val isSelected = selectedAR == ar
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) HubSecondaryCyan else HubDarkSurfaceVariant)
              .clickable { selectedAR = ar }
              .padding(horizontal = 14.dp, vertical = 6.dp)
          ) {
            Text(
              text = ar,
              color = if (isSelected) Color.Black else Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Copy Full Prompt with parameters button
      Button(
        onClick = {
          val fullCommand = "${item.promptText} --ar $selectedAR --v 6.1 --seed ${item.seed}"
          onCopyNotification("Copied full prompt with --ar $selectedAR to clipboard!")
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(46.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = HubPrimaryPurple)
      ) {
        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Copy Full Prompt & Parameters", color = Color.White, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
