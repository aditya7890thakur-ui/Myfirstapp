package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.WallpaperItem
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@Composable
fun WallpaperHavenSection(
  wallpapers: List<WallpaperItem>,
  onWallpaperClick: (WallpaperItem) -> Unit,
  onViewAllClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp)
  ) {
    // Section Header with Title & Action Button
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(HubPrimaryPurple)
        )
        Text(
          text = "Wallpaper Haven",
          color = HubTextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp,
          modifier = Modifier.testTag("wallpaper_haven_title")
        )
        Text(
          text = "4K / 8K",
          color = HubSecondaryCyan,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(HubSecondaryCyan.copy(alpha = 0.15f))
            .padding(horizontal = 5.dp, vertical = 2.dp)
        )
      }

      // VIEW ALL text button
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .clickable { onViewAllClick() }
          .padding(horizontal = 8.dp, vertical = 4.dp)
          .testTag("wallpaper_haven_header_view_all"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text(
          text = "VIEW ALL",
          color = HubPrimaryPurple,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.8.sp
        )
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = "View all wallpapers",
          tint = HubPrimaryPurple,
          modifier = Modifier.size(14.dp)
        )
      }
    }

    // Shows four preview thumbnails:
    // 1. "Dark Aesthetics" (an astronaut)
    // 2. "Cyberpunk" (neon city)
    // 3. "Nature High-Res" (mountain)
    // 4. "VIEW ALL" button
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 1-3: Wallpapers
      items(wallpapers) { wallpaper ->
        WallpaperPreviewCard(
          wallpaper = wallpaper,
          onClick = { onWallpaperClick(wallpaper) }
        )
      }

      // 4th item: "VIEW ALL" thumbnail card
      item {
        ViewAllWallpaperCard(
          totalCount = "1,840+",
          onClick = onViewAllClick
        )
      }
    }
  }
}

@Composable
fun WallpaperPreviewCard(
  wallpaper: WallpaperItem,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .width(140.dp)
      .aspectRatio(9f / 16f)
      .clip(RoundedCornerShape(16.dp))
      .border(1.dp, HubDarkBorder, RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("wallpaper_card_${wallpaper.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = HubDarkSurface)
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      if (wallpaper.imageRes != null) {
        Image(
          painter = painterResource(id = wallpaper.imageRes),
          contentDescription = wallpaper.title,
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
      } else {
        // Fallback atmospheric canvas
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(Color(0xFF1E1B4B), Color(0xFF090A0F))
              )
            )
        )
      }

      // Vignette gradient overlay
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Black.copy(alpha = 0.2f),
                Color.Transparent,
                Color.Black.copy(alpha = 0.85f)
              )
            )
          )
      )

      // Top Tag Badge
      Box(
        modifier = Modifier
          .padding(8.dp)
          .align(Alignment.TopStart)
          .clip(RoundedCornerShape(6.dp))
          .background(Color.Black.copy(alpha = 0.6f))
          .border(0.5.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
          .padding(horizontal = 6.dp, vertical = 2.dp)
      ) {
        Text(
          text = wallpaper.tag,
          color = Color.White,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // Bottom Info
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(10.dp)
      ) {
        Text(
          text = wallpaper.title,
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Download,
            contentDescription = null,
            tint = HubSecondaryCyan,
            modifier = Modifier.size(11.dp)
          )
          Text(
            text = wallpaper.downloads,
            color = HubTextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }
  }
}

@Composable
fun ViewAllWallpaperCard(
  totalCount: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .width(140.dp)
      .aspectRatio(9f / 16f)
      .clip(RoundedCornerShape(16.dp))
      .border(1.5.dp, HubPrimaryPurple.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .testTag("wallpaper_haven_view_all_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = HubDarkSurfaceVariant)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            listOf(
              Color(0xFF2E1065).copy(alpha = 0.6f),
              Color(0xFF0F172A)
            )
          )
        )
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(HubPrimaryPurple.copy(alpha = 0.25f))
            .border(1.dp, HubPrimaryPurple, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "View All",
            tint = Color.White,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "VIEW ALL",
          color = Color.White,
          fontSize = 14.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.2.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = totalCount,
          color = HubSecondaryCyan,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = "Wallpapers",
          color = HubTextMuted,
          fontSize = 10.sp
        )
      }
    }
  }
}

/**
 * Fullscreen Wallpaper Detail Dialog
 */
@Composable
fun WallpaperDetailDialog(
  wallpaper: WallpaperItem,
  isBookmarked: Boolean,
  onToggleBookmark: () -> Unit,
  onDismiss: () -> Unit,
  onApplyToast: (String) -> Unit
) {
  var isApplied by remember { mutableStateOf(false) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = Color.Black
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        // High resolution wallpaper preview
        if (wallpaper.imageRes != null) {
          Image(
            painter = painterResource(id = wallpaper.imageRes),
            contentDescription = wallpaper.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
        }

        // Top Gradient overlay with close & bookmark buttons
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)
              )
            )
            .padding(top = 36.dp, start = 16.dp, end = 16.dp, bottom = 20.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.6f))
            ) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              IconButton(
                onClick = onToggleBookmark,
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(Color.Black.copy(alpha = 0.6f))
              ) {
                Icon(
                  imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                  contentDescription = "Bookmark",
                  tint = if (isBookmarked) HubSecondaryCyan else Color.White
                )
              }
            }
          }
        }

        // Bottom Details Sheet overlay
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color.Black.copy(alpha = 0.95f), Color.Black)
              )
            )
            .padding(20.dp)
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(HubPrimaryPurple)
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = wallpaper.category.uppercase(),
              color = Color.White,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = wallpaper.title,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(4.dp))

          // Tech Specs Row
          Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Res: ${wallpaper.resolution}", color = HubTextSecondary, fontSize = 12.sp)
            Text(text = "•", color = HubTextMuted)
            Text(text = "Size: ${wallpaper.fileSize}", color = HubTextSecondary, fontSize = 12.sp)
            Text(text = "•", color = HubTextMuted)
            Text(text = "Downloads: ${wallpaper.downloads}", color = HubSecondaryCyan, fontSize = 12.sp)
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Action Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Button(
              onClick = {
                isApplied = true
                onApplyToast("Wallpaper '${wallpaper.title}' applied to home screen!")
              },
              modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("apply_wallpaper_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isApplied) HubSecondaryCyan else HubPrimaryPurple
              )
            ) {
              Icon(
                imageVector = if (isApplied) Icons.Default.CheckCircle else Icons.Default.Wallpaper,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isApplied) "Applied to Device" else "Set as Wallpaper",
                color = Color.White,
                fontWeight = FontWeight.Bold
              )
            }

            OutlinedButton(
              onClick = {
                onApplyToast("Saved 4K UHD file (${wallpaper.fileSize}) to Pictures/Wallpapers")
              },
              modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("download_wallpaper_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(HubSecondaryCyan, HubPrimaryPurple)))
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                tint = HubSecondaryCyan,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Download 4K",
                color = Color.White,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }
}
