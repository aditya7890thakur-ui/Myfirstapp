package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HubDarkBorder
import com.example.ui.theme.HubDarkSurface
import com.example.ui.theme.HubDarkSurfaceVariant
import com.example.ui.theme.HubPrimaryPurple
import com.example.ui.theme.HubSecondaryCyan
import com.example.ui.theme.HubTextMuted
import com.example.ui.theme.HubTextPrimary
import com.example.ui.theme.HubTextSecondary

@Composable
fun StudioHeader(
  currentTime: String = "11:33",
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  isSearchActive: Boolean,
  onToggleSearch: () -> Unit,
  savedBookmarksCount: Int,
  onOpenBookmarks: () -> Unit,
  selectedCategoryTab: String,
  onSelectCategoryTab: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(
        brush = Brush.verticalGradient(
          colors = listOf(
            Color(0xFF0F121C),
            Color(0xFF090A0F)
          )
        )
      )
  ) {
    // Top Status & App Bar with "CREATIVE HUB" and "11:33"
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: App Name badge
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
              brush = Brush.linearGradient(
                listOf(HubPrimaryPurple, HubSecondaryCyan)
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "Creative Hub Logo",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        Column {
          Text(
            text = "CREATIVE HUB",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            letterSpacing = 1.2.sp,
            modifier = Modifier.testTag("app_bar_title")
          )
          Text(
            text = "STUDIO PRO",
            color = HubSecondaryCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
          )
        }
      }

      // Right: Time display "11:33" and Quick Actions (Search, Bookmarks)
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Clock Capsule "11:33"
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(HubDarkSurfaceVariant)
            .border(1.dp, HubDarkBorder, RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .testTag("clock_badge"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(HubSecondaryCyan)
            )
            Text(
              text = currentTime,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 0.5.sp
            )
          }
        }

        // Search Button
        IconButton(
          onClick = onToggleSearch,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isSearchActive) HubPrimaryPurple.copy(alpha = 0.2f) else HubDarkSurfaceVariant)
            .testTag("search_toggle_button")
        ) {
          Icon(
            imageVector = if (isSearchActive) Icons.Default.Close else Icons.Outlined.Search,
            contentDescription = "Search",
            tint = if (isSearchActive) HubSecondaryCyan else Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        // Saved Items / Bookmarks
        IconButton(
          onClick = onOpenBookmarks,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(HubDarkSurfaceVariant)
            .testTag("bookmarks_button")
        ) {
          BadgedBox(
            badge = {
              if (savedBookmarksCount > 0) {
                Badge(
                  containerColor = HubPrimaryPurple,
                  contentColor = Color.White
                ) {
                  Text(text = "$savedBookmarksCount", fontSize = 10.sp)
                }
              }
            }
          ) {
            Icon(
              imageVector = if (savedBookmarksCount > 0) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
              contentDescription = "Bookmarks",
              tint = if (savedBookmarksCount > 0) HubSecondaryCyan else Color.White,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }

    // Expandable Search Bar
    AnimatedVisibility(
      visible = isSearchActive,
      enter = fadeIn() + expandVertically(),
      exit = fadeOut() + shrinkVertically()
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchQueryChange,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_input_field"),
          placeholder = { Text("Search wallpapers, presets, manhwa, prompts...", color = HubTextMuted, fontSize = 13.sp) },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = HubSecondaryCyan,
              modifier = Modifier.size(18.dp)
            )
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchQueryChange("") }) {
                Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = "Clear search",
                  tint = HubTextMuted,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = HubSecondaryCyan,
            unfocusedBorderColor = HubDarkBorder,
            focusedContainerColor = HubDarkSurface,
            unfocusedContainerColor = HubDarkSurface,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          )
        )
      }
    }

    // Large Bold White Text: "CREATIVE HUB"
    // Smaller text below: "Presets, Wallpapers, Prompts & More"
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(
          brush = Brush.linearGradient(
            colors = listOf(
              Color(0xFF161926),
              Color(0xFF0F121D)
            )
          )
        )
        .border(1.dp, HubDarkBorder, RoundedCornerShape(16.dp))
        .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
      Column {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(HubSecondaryCyan.copy(alpha = 0.2f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "PRO ASSET VAULT",
              color = HubSecondaryCyan,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }

          Text(
            text = "• 2026 EDITION",
            color = HubTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "CREATIVE HUB",
          color = Color.White,
          fontSize = 28.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.2.sp,
          modifier = Modifier.testTag("hero_bold_title")
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = "Presets, Wallpapers, Prompts & More",
          color = HubTextSecondary,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium,
          letterSpacing = 0.3.sp,
          modifier = Modifier.testTag("hero_subtitle")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Quick jump filter chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          val tabs = listOf(
            "All Vault",
            "Wallpapers",
            "Editing Presets",
            "Manhwa Edits",
            "AI Prompts"
          )

          tabs.forEach { tabName ->
            val isSelected = selectedCategoryTab == tabName
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                  if (isSelected) HubPrimaryPurple else HubDarkSurfaceVariant
                )
                .border(
                  1.dp,
                  if (isSelected) HubPrimaryPurple else HubDarkBorder,
                  RoundedCornerShape(20.dp)
                )
                .clickable { onSelectCategoryTab(tabName) }
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .testTag("filter_tab_${tabName.replace(" ", "_").lowercase()}"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = tabName,
                color = if (isSelected) Color.White else HubTextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
        }
      }
    }
  }
}
