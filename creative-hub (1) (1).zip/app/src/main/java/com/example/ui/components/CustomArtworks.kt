package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * High-fidelity procedural artwork for "Cinematic LUTs" (City bridge with dramatic dusk teal & orange grading)
 */
@Composable
fun CinematicBridgeArtwork(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height

    // Sky gradient: Dusk orange to deep teal night
    drawRect(
      brush = Brush.verticalGradient(
        colors = listOf(
          Color(0xFF0F172A),
          Color(0xFF1E293B),
          Color(0xFF0E7490),
          Color(0xFFF97316),
          Color(0xFF7C2D12)
        )
      )
    )

    // Distant city skyline silhouettes
    val buildingPaint = Color(0xFF090D16)
    val buildingCount = 9
    val buildingWidth = w / buildingCount
    for (i in 0 until buildingCount) {
      val bh = h * (0.25f + ((i * 37) % 20) / 100f)
      drawRect(
        color = buildingPaint,
        topLeft = Offset(i * buildingWidth, h * 0.55f - bh),
        size = Size(buildingWidth * 0.95f, bh + h * 0.45f)
      )
      // Building windows
      for (row in 0..4) {
        if ((i + row) % 2 == 0) {
          drawCircle(
            color = Color(0xFFFED7AA).copy(alpha = 0.7f),
            radius = 1.5f,
            center = Offset(i * buildingWidth + buildingWidth * 0.35f, h * 0.55f - bh + row * 12f + 8f)
          )
        }
      }
    }

    // River water surface
    drawRect(
      brush = Brush.verticalGradient(
        colors = listOf(Color(0xFF042F2E), Color(0xFF021B1A)),
        startY = h * 0.65f,
        endY = h
      ),
      topLeft = Offset(0f, h * 0.65f),
      size = Size(w, h * 0.35f)
    )

    // Water reflections
    for (i in 0..6) {
      drawOval(
        color = Color(0xFFF97316).copy(alpha = 0.22f),
        topLeft = Offset(w * (0.15f + i * 0.12f), h * 0.67f + (i % 3) * 14f),
        size = Size(w * 0.14f, 4f)
      )
    }

    // Suspension Bridge structure
    val bridgeColor = Color(0xFF05070B)
    val cableColor = Color(0xFFE2E8F0).copy(alpha = 0.75f)

    // Bridge deck
    drawRect(
      color = bridgeColor,
      topLeft = Offset(0f, h * 0.62f),
      size = Size(w, h * 0.04f)
    )

    // Bridge towers (2 main suspension towers)
    val tower1X = w * 0.30f
    val tower2X = w * 0.70f
    val towerWidth = w * 0.05f
    val towerTopY = h * 0.18f

    // Tower 1
    drawRect(color = bridgeColor, topLeft = Offset(tower1X - towerWidth / 2, towerTopY), size = Size(towerWidth, h * 0.44f))
    // Tower 2
    drawRect(color = bridgeColor, topLeft = Offset(tower2X - towerWidth / 2, towerTopY), size = Size(towerWidth, h * 0.44f))

    // Main Suspension Cables (curving path)
    val cablePath = Path().apply {
      moveTo(0f, h * 0.40f)
      quadraticTo(tower1X * 0.5f, h * 0.58f, tower1X, towerTopY)
      quadraticTo(w * 0.5f, h * 0.56f, tower2X, towerTopY)
      quadraticTo((tower2X + w) * 0.5f, h * 0.58f, w, h * 0.40f)
    }
    drawPath(path = cablePath, color = cableColor, style = Stroke(width = 2.5f))

    // Vertical suspension lines
    for (x in (tower1X.toInt()..(tower2X.toInt()) step (w * 0.045f).toInt())) {
      val fx = x.toFloat()
      val ratio = (fx - tower1X) / (tower2X - tower1X)
      val cableY = towerTopY + (h * 0.56f - towerTopY) * 4f * ratio * (1f - ratio)
      drawLine(
        color = Color(0xFF94A3B8).copy(alpha = 0.45f),
        start = Offset(fx, cableY),
        end = Offset(fx, h * 0.62f),
        strokeWidth = 1f
      )
    }

    // Bridge road lights (Warm golden bokeh dots)
    for (i in 0..12) {
      val lightX = (w / 12f) * i
      drawCircle(
        color = Color(0xFFFBBF24),
        radius = 3.5f,
        center = Offset(lightX, h * 0.615f)
      )
      drawCircle(
        color = Color(0xFFFBBF24).copy(alpha = 0.25f),
        radius = 7.5f,
        center = Offset(lightX, h * 0.615f)
      )
    }
  }
}

/**
 * High-fidelity procedural artwork for "Slo Mo Effect" (Athletic runner with neon motion blur trails)
 */
@Composable
fun SloMoRunnerArtwork(modifier: Modifier = Modifier) {
  val infiniteTransition = rememberInfiniteTransition(label = "runner_trail")
  val pulse by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(1800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse"
  )

  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height

    // Deep dynamic dark studio canvas
    drawRect(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFF1E1B4B), Color(0xFF0B0D17), Color(0xFF030712)),
        center = Offset(w * 0.55f, h * 0.45f),
        radius = w * 0.85f
      )
    )

    // Motion speed grid / track lines
    val trackColor = Color(0xFF38BDF8).copy(alpha = 0.15f)
    for (i in 1..5) {
      drawLine(
        color = trackColor,
        start = Offset(0f, h * (0.6f + i * 0.07f)),
        end = Offset(w, h * (0.6f + i * 0.07f)),
        strokeWidth = 1.2f
      )
    }

    // Multiple exposure runner trails (Echo / Slo Mo effect)
    val trailOffsets = listOf(
      Offset(-w * 0.30f, 0f) to Color(0xFFEC4899).copy(alpha = 0.25f * (1f - pulse * 0.3f)),
      Offset(-w * 0.18f, 0f) to Color(0xFF8B5CF6).copy(alpha = 0.45f),
      Offset(-w * 0.08f, 0f) to Color(0xFF06B6D4).copy(alpha = 0.65f),
      Offset(0f, 0f) to Color(0xFFFFFFFF)
    )

    val cx = w * 0.58f
    val cy = h * 0.48f

    trailOffsets.forEach { (offset, color) ->
      val x = cx + offset.x
      val y = cy + offset.y

      // Running figure: Head
      drawCircle(
        color = color,
        radius = w * 0.065f,
        center = Offset(x + w * 0.05f, y - h * 0.18f)
      )

      // Torso angled forward
      val torsoPath = Path().apply {
        moveTo(x + w * 0.04f, y - h * 0.12f)
        lineTo(x - w * 0.03f, y + h * 0.03f)
        lineTo(x - w * 0.08f, y + h * 0.02f)
        lineTo(x - w * 0.01f, y - h * 0.12f)
        close()
      }
      drawPath(path = torsoPath, color = color)

      // Forward Leg (Knee lifted high)
      val frontLeg = Path().apply {
        moveTo(x - w * 0.03f, y + h * 0.03f)
        lineTo(x + w * 0.10f, y + h * 0.08f)
        lineTo(x + w * 0.12f, y + h * 0.20f)
      }
      drawPath(path = frontLeg, color = color, style = Stroke(width = w * 0.04f))

      // Back Leg (Extended back)
      val backLeg = Path().apply {
        moveTo(x - w * 0.06f, y + h * 0.02f)
        lineTo(x - w * 0.18f, y + h * 0.10f)
        lineTo(x - w * 0.26f, y + h * 0.16f)
      }
      drawPath(path = backLeg, color = color, style = Stroke(width = w * 0.035f))

      // Forward Arm & Back Arm
      val frontArm = Path().apply {
        moveTo(x + w * 0.02f, y - h * 0.10f)
        lineTo(x - w * 0.08f, y - h * 0.04f)
        lineTo(x - w * 0.14f, y - h * 0.12f)
      }
      drawPath(path = frontArm, color = color, style = Stroke(width = w * 0.03f))

      val backArm = Path().apply {
        moveTo(x + w * 0.03f, y - h * 0.10f)
        lineTo(x + w * 0.12f, y - h * 0.04f)
        lineTo(x + w * 0.18f, y + h * 0.02f)
      }
      drawPath(path = backArm, color = color, style = Stroke(width = w * 0.03f))
    }

    // Kinetic speed streaks & particles
    for (i in 0..15) {
      val sx = (w * 0.05f) + (i * 29) % (w.toInt())
      val sy = h * 0.2f + ((i * 47) % (h * 0.6f).toInt())
      val streakLen = w * (0.08f + ((i % 4) * 0.04f))
      drawLine(
        brush = Brush.horizontalGradient(
          listOf(Color.Transparent, Color(0xFF06B6D4).copy(alpha = 0.6f), Color.White)
        ),
        start = Offset(sx, sy),
        end = Offset(sx + streakLen, sy),
        strokeWidth = 2f
      )
    }
  }
}

/**
 * Stylized manhwa portrait canvas with dynamic anime aura effect
 */
@Composable
fun ManhwaPortraitCanvas(
  characterName: String,
  primaryColor: Color,
  secondaryColor: Color,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "aura_pulse")
  val auraGlow by infiniteTransition.animateFloat(
    initialValue = 0.6f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(1500, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow"
  )

  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height

    // Dramatic vignette background
    drawRect(
      brush = Brush.radialGradient(
        colors = listOf(primaryColor.copy(alpha = 0.35f * auraGlow), Color(0xFF0A0C14), Color(0xFF040508)),
        center = Offset(w * 0.5f, h * 0.45f),
        radius = w * 0.75f
      )
    )

    // Dynamic aura flame curves in background
    for (i in 0..5) {
      val flameAngle = (i * 60f)
      val fx = w * 0.5f + (Math.cos(Math.toRadians(flameAngle.toDouble())).toFloat() * w * 0.25f)
      val fy = h * 0.4f + (Math.sin(Math.toRadians(flameAngle.toDouble())).toFloat() * h * 0.25f)
      drawCircle(
        color = secondaryColor.copy(alpha = 0.18f * auraGlow),
        radius = w * 0.22f,
        center = Offset(fx, fy)
      )
    }

    // Stylized Character Silhouette & Features
    val cx = w * 0.5f
    val cy = h * 0.55f

    // Neck and shoulders
    val shoulderPath = Path().apply {
      moveTo(cx - w * 0.38f, h)
      lineTo(cx - w * 0.22f, cy + h * 0.15f)
      lineTo(cx - w * 0.10f, cy + h * 0.08f)
      lineTo(cx + w * 0.10f, cy + h * 0.08f)
      lineTo(cx + w * 0.22f, cy + h * 0.15f)
      lineTo(cx + w * 0.38f, h)
      close()
    }
    drawPath(path = shoulderPath, color = Color(0xFF0E111B))

    // Jawline & Face base
    val facePath = Path().apply {
      moveTo(cx - w * 0.18f, cy - h * 0.12f)
      lineTo(cx - w * 0.16f, cy + h * 0.04f)
      lineTo(cx, cy + h * 0.14f) // Sharp manhwa chin
      lineTo(cx + w * 0.16f, cy + h * 0.04f)
      lineTo(cx + w * 0.18f, cy - h * 0.12f)
      close()
    }
    drawPath(
      path = facePath,
      brush = Brush.verticalGradient(
        listOf(Color(0xFF232A3B), Color(0xFF131722))
      )
    )

    // Manhwa anime spiky hair
    val hairPath = Path().apply {
      moveTo(cx - w * 0.25f, cy - h * 0.05f)
      lineTo(cx - w * 0.32f, cy - h * 0.22f)
      lineTo(cx - w * 0.18f, cy - h * 0.25f)
      lineTo(cx - w * 0.12f, cy - h * 0.36f)
      lineTo(cx, cy - h * 0.28f)
      lineTo(cx + w * 0.14f, cy - h * 0.38f)
      lineTo(cx + w * 0.22f, cy - h * 0.25f)
      lineTo(cx + w * 0.30f, cy - h * 0.18f)
      lineTo(cx + w * 0.24f, cy - h * 0.04f)
      lineTo(cx + w * 0.15f, cy - h * 0.10f)
      lineTo(cx + w * 0.05f, cy - h * 0.02f)
      lineTo(cx - w * 0.08f, cy - h * 0.03f)
      lineTo(cx - w * 0.18f, cy - h * 0.09f)
      close()
    }
    drawPath(path = hairPath, color = Color(0xFF080A10))

    // Piercing glowing eyes (Signature manhwa intense gaze)
    val leftEyeX = cx - w * 0.09f
    val rightEyeX = cx + w * 0.09f
    val eyeY = cy - h * 0.02f

    // Eye glow halo
    drawCircle(color = primaryColor.copy(alpha = 0.55f * auraGlow), radius = w * 0.06f, center = Offset(leftEyeX, eyeY))
    drawCircle(color = primaryColor.copy(alpha = 0.55f * auraGlow), radius = w * 0.06f, center = Offset(rightEyeX, eyeY))

    // Sharp glowing pupils
    drawOval(
      color = Color.White,
      topLeft = Offset(leftEyeX - w * 0.04f, eyeY - 2.5f),
      size = Size(w * 0.08f, 5f)
    )
    drawOval(
      color = Color.White,
      topLeft = Offset(rightEyeX - w * 0.04f, eyeY - 2.5f),
      size = Size(w * 0.08f, 5f)
    )

    // Lightning spark or aura flares
    drawLine(
      color = primaryColor,
      start = Offset(leftEyeX + w * 0.04f, eyeY),
      end = Offset(leftEyeX + w * 0.12f, eyeY - h * 0.04f),
      strokeWidth = 2.5f
    )
    drawLine(
      color = primaryColor,
      start = Offset(rightEyeX + w * 0.04f, eyeY),
      end = Offset(rightEyeX + w * 0.14f, eyeY - h * 0.05f),
      strokeWidth = 2.5f
    )
  }
}
