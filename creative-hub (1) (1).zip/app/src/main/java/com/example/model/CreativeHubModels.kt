package com.example.model

import androidx.annotation.DrawableRes

data class WallpaperItem(
  val id: String,
  val title: String,
  val category: String,
  val tag: String,
  @DrawableRes val imageRes: Int?,
  val downloads: String,
  val resolution: String = "3840 × 2160 UHD",
  val fileSize: String = "12.4 MB",
  val paletteColors: List<Long> = listOf(0xFF8B5CF6, 0xFF06B6D4, 0xFF0F172A)
)

data class PresetItem(
  val id: String,
  val title: String,
  val subtitle: String,
  val category: String,
  @DrawableRes val imageRes: Int?,
  val presetType: String, // "LUT / DNG / XMP"
  val downloadCount: String,
  val exposure: Float = 0.25f,
  val contrast: Float = 0.40f,
  val highlights: Float = -0.30f,
  val shadows: Float = 0.20f,
  val temp: Float = 0.15f,
  val grain: Float = 0.35f,
  val description: String
)

data class ManhwaEditItem(
  val id: String,
  val characterName: String,
  val series: String,
  val auraType: String,
  val primaryAuraColor: Long,
  val secondaryColor: Long,
  val chapterRef: String,
  val soundEffect: String,
  val quote: String,
  val editTags: List<String>
)

data class AIPromptItem(
  val id: String,
  val title: String,
  val promptText: String,
  val negativePrompt: String,
  val aspectRatio: String,
  val recommendedModel: String,
  val tags: List<String>,
  val seed: Long = 4829103L
)
