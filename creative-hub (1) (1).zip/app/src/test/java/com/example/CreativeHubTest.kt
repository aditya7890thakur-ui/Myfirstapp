package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.ui.CreativeHubScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CreativeHubTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun testCreativeHubSectionsDisplayed() {
    composeTestRule.setContent {
      MyApplicationTheme {
        CreativeHubScreen()
      }
    }

    // Verify Header Elements
    composeTestRule.onNodeWithTag("system_status_time").assertIsDisplayed()
    composeTestRule.onNodeWithTag("header_title").assertIsDisplayed()
    composeTestRule.onNodeWithTag("header_subtitle").assertIsDisplayed()

    // Verify Main Sections
    composeTestRule.onNodeWithTag("wallpaper_haven_title").assertIsDisplayed()
    composeTestRule.onNodeWithTag("view_all_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("editing_presets_title").assertIsDisplayed()
    composeTestRule.onNodeWithTag("manhwa_edits_title").assertIsDisplayed()
    composeTestRule.onNodeWithTag("ai_prompts_title").assertIsDisplayed()
  }
}
